#bootstrap 
	是目前最流行的 HTML, CSS 和 JavaScript 框架，用于开发响应式，移动端先行的 web 项目。

github地址：https://github.com/twbs/bootstrap
中文文档：http://www.bootcss.com/

本地版本： 3.3.7
更新日期：

介绍：
  Bootstrap，来自 Twitter，是目前最受欢迎的前端框架。Bootstrap 是基于 HTML、CSS、JAVASCRIPT 的，它简洁灵活，使得 Web 开发更加快捷。


  基于bootstrop的插件放在当前目录下面

bootstrap-slider官方示例：
https://seiyria.com/bootstrap-slider/
