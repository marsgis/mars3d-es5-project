#nprogress 页面加载进度条

github地址：https://github.com/rstacruz/nprogress
官方网站：https://ricostacruz.com/nprogress/
 
 


  