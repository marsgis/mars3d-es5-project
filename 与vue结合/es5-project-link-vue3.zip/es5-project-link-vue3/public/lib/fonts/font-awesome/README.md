#font-awesome Font Awesome 是一整套包含 585 个象形矢量图标的字体库


github地址：https://github.com/FortAwesome/Font-Awesome
官方网站：https://fontawesome.com/
中文网站：http://fontawesome.dashgame.com/


本地版本： 4.7.0
更新日期：

介绍：
	 不需要 JavaScript，由 CSS 控制，可完全控制图标的大小和颜色样式
