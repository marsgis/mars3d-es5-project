#hao 木遥常用js的静态方法类库
  

github地址：https://github.com/muyao1987/haoutil
作者：木遥，微信:  http://marsgis.cn/weixin.html 


介绍：
	 该目录是木遥个人开发的js类库目录 
