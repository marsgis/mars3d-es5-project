#mapv 百度地图的大数据可视化开源库

github地址：https://github.com/huiyan-fe/mapv/#readme
官方网站：http://mapv.baidu.com/


本地版本： 2.0.12
更新日期：2017-3-21

介绍：
	    Mapv 是一款基于百度地图的大数据可视化开源库,可以用来展示大量的点、线、面的数据,每种数据也有不同的展示类型,如直接打点、热力图、网格、聚合等方式展示数据。
