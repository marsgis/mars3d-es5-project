#toastr 通知提示插件

github地址：https://github.com/CodeSeven/toastr 
官方网址：http://www.toastrjs.com


toastr.js是一个基于jQuery的非阻塞通知的JavaScript库。
toastr.js可以设定四种通知模式：成功、出错、警告、提示。提示窗口的位置、动画效果等都可以通过参数来设置，
并且可以在官方网站上通过勾选参数来生成JavaScript代码，操作简单，容易上手，推荐使用。
 