# mars3d-plugin-tdt

Mars3D平台插件, 支持对 天地图三维地名服务和地形服务加载使用
 
天地图三维地名服务和地形服务, 需要利用 cesium 与天地图扩展插件共同使用.
天地图三维地名服务和三维地形服务对所有用户开放,使用本组服务之前，需要在天地图官网申请key

## 查看源码
  https://github.com/marsgis/mars3d-plugin/

### 内部说明 
内嵌了天地图官方插件
github地址：https://github.com/ngcc-tdt/plugin  [实际未开源，里面是压缩混淆的的代码]
帮助文档：http://lbs.tianditu.gov.cn/docs/#/sanwei/
