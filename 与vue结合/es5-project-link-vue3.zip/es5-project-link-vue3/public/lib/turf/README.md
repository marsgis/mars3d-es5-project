#turf GIS地图空间分析库

github地址：https://github.com/Turfjs/turf
官方网站：http://turfjs.org/


本地版本： 6.3.0 

介绍：
	    turfjs是一个用于空间分析的JavaScript库。它包括传统的空间操作，用于创建GeoJSON数据的帮助函数，以及数据分类和统计工具。
