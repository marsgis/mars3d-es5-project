#echarts  百度团队开发的一款商业级数据图表


github地址：https://github.com/ecomfe/echarts
中文文档：https://echarts.apache.org/zh/index.html

GL:https://github.com/ecomfe/echarts-gl
水球：https://github.com/ecomfe/echarts-liquidfill


本地版本：echarts-5.2.2 , echarts-gl-2.0.8
更新日期：

介绍：
	提供商业产品常用图表库，底层基于ZRender，创建了坐标系，图例，提示，工具箱等基础组件，并在此上构出折线图（区域图），柱状图（条状图），散点图（气泡图），饼图（环形图），K线图，地图，和弦图以及力导向布局图，同时支持任意维度的堆积和多图表混合展现。
