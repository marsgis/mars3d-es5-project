/* eslint-disable */
export {}
declare global {
    interface Window {
        mars3d: any;
        basePathUrl: String;
        MonacoEnvironment: any;
        eventBus: any;
        mars3dExampleConfig: any;
        map: any;
    }
}
